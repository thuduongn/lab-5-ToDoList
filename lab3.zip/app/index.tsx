import App from '@/components/app';
import { Image, StyleSheet, Platform } from 'react-native';

export default function HomeScreen() {
  return (
    <App />
  );
}

